//
//  iconAppSwiftUIApp.swift
//  iconAppSwiftUI
//
//  Created by Ahmed Salah on 25/10/2022.
//

import SwiftUI

@main
struct iconAppSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
