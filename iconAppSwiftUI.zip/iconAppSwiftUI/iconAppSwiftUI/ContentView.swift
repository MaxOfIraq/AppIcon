//
//  ContentView.swift
//  iconAppSwiftUI
//
//  Created by Ahmed Salah on 25/10/2022.
//

import SwiftUI

struct ContentView: View {
    
    @AppStorage("Active_Icon") var act : String = "AppIcon"
    
    var body: some View {
        NavigationStack{
            List{
                HStack{
                    Text("Chous your icon")
                    Picker(selection: $act){
                        let coustom : [String] = ["AppIcon 1","AppIcon 2","AppIcon 3"]
                        ForEach(coustom, id: \.self){ icon in
                            Text(icon)
                                .tag(icon)
                        }
                    }label: {
                        
                    }
                }
            }
        }.navigationTitle("Icon App")
            .onChange(of: act){ newIcon in
                UIApplication.shared.setAlternateIconName(newIcon)
            }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
